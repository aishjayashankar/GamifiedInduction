import { sign } from "crypto";

//signup
const signupForm = document.querySelector('#ureg')
signupForm.addEventListener('submit',(e)=>{
    e.preventDefault();
    //get user info
    const email = signupForm['regEmail'].value;
    const name = signupForm['regName'].value;
    const pass = signupForm['regPass'].value;
    console.log(email,pass,name)
})