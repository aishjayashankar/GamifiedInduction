import React, { Component } from 'react';

class Butiles extends Component {

    render() {
      return (
        
        <div className="App"><br/><br/>
      <div className="t"><h3>BUSINESS UNITS</h3></div>
        <button class="bu1button">PBM</button>
        <button class="bu1button">PBB</button>
        <button class="bu1button">CPB</button>
        <button class="bu1button">ES</button>
        
    </div>
        
      );
  
      }
    }
        export default Butiles;